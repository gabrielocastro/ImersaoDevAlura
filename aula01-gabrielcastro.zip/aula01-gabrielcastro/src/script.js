function conversorDol() {
  let realValor = prompt("Digite o valor em Reais");
  let dollar = 5.69;
  alert("U$ " + (realValor / dollar).toFixed(2));
}

function conversorEuro() {
  let realValor = prompt("Digite o valor em Reais");
  let euro = 6.16;
  alert("€$ " + (realValor / euro).toFixed(2));
}

function conversorLibra() {
  let realValor = prompt("Digite o valor em Reais");
  let libra = 7.37;
  alert("£$ " + (realValor / libra).toFixed(2));
}