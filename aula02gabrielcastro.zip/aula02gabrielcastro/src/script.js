function jogar() {
  let age = prompt("Quantos anos você tem?");
  
  if (age >= 12) {
    let game = true;
    alert("Ok, vamos começar o jogo");
    
    let win = "Parabéns! Seu time venceu!";
    let lose = "Que pena! Seu time perdeu!";
    let battle = "O jogo foi intenso, mas ainda não terminou!";
    
    while (game) {
      let escolha = parseInt(prompt("Escolha seu time: 1-Fluminense; 2-Brasil; 3-Uruguai; 4-Estados Unidos"));
      let adversario = Math.floor(Math.random() * 4) + 1;

      if (adversario === 1) { // Fluminense adversário
        if (escolha === 2) { // Brasil perde para Fluminense
          alert(lose);
          game = false;
        } else if (escolha === 1) {
          alert("O jogo foi equilibrado! Empate.");
          game = false;
        } else {
          alert(battle);
        }

      } else if (adversario === 2) { // Brasil adversário
        if (escolha === 3) { // Uruguai perde para Brasil
          alert(lose);
          game = false;
        } else if (escolha === 1) { // Fluminense vence Brasil
          alert(win);
          game = false;
        } else {
          alert(battle);
        }

      } else if (adversario === 3) { // Uruguai adversário
        if (escolha === 4) { // EUA perde para Uruguai
          alert(lose);
          game = false;
        } else if (escolha === 2) { // Brasil vence Uruguai
          alert(win);
          game = false;
        } else {
          alert(battle);
        }

      } else if (adversario === 4) { // EUA adversário
        if (escolha === 3) { // Uruguai vence EUA
          alert(win);
          game = false;
        } else if (escolha === 4) {
          alert("O jogo foi equilibrado! Empate.");
          game = false;
        } else {
          alert(battle);
        }
      }
    }
  } else {
    alert("Você é muito jovem para esse jogo, volte quando for mais velho.");
  }
}
