function jogar() {
  let rodada = 1;
  let campeao = true; 
  let venceu = false; 

  let nomeJogador = prompt("Qual é o seu nome?");
  
  if (!nomeJogador || nomeJogador.trim() === "") {
    alert("Por favor, insira um nome válido.");
    return;
  }

  alert(`Bem-vindo à Copa, ${nomeJogador}! Para ser campeão, vença 7 partidas seguidas.`);

  let time = parseInt(prompt(`${nomeJogador}, escolha seu time: 1-Brasil; 2-Uruguai; 3-Estados Unidos`));

  if (time < 1 || time > 3 || isNaN(time)) {
    alert("Escolha um time válido entre 1 e 3.");
    return;
  }

  while (rodada <= 7) {
    console.log(`Rodada: ${rodada}`);

    let adversario = Math.floor(Math.random() * 3) + 1;
    
    while (adversario == time) {
      adversario = Math.floor(Math.random() * 3) + 1;
    }

    let resultado = Math.random(); 

    if (resultado < 0.5) { // Perdeu
      alert(`Que pena, ${nomeJogador}! Seu time foi eliminado na rodada ${rodada}.`);
      campeao = false;
      break;
    } else { // Venceu
      alert(`Boa, ${nomeJogador}! Você venceu a rodada ${rodada} e segue na competição.`);
    }

    rodada++;
  }

  if (campeao) {
    alert(`Parabéns, ${nomeJogador}! Seu time venceu a Copa! 🏆`);
    venceu = true; 
  } else {
    alert(`Infelizmente seu time foi eliminado, ${nomeJogador}. Tente novamente!`);
  }

  console.log(`Jogador ${nomeJogador} venceu a Copa?`, venceu);
}
