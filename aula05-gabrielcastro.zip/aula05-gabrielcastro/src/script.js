const perguntas = [
  {
    pergunta: "Qual ano o Fluminense foi fundado?",
    respostas: [
      { opcao: "1902", correto: true },
      { opcao: "1903", correto: false },
      { opcao: "1905", correto: false }
    ]
  },
  {
    pergunta: "Qual estádio é a casa do Fluminense?",
    respostas: [
      { opcao: "São Januário", correto: false },
      { opcao: "Engenhão", correto: false },
      { opcao: "Maracanã", correto: true }
    ]
  },
  {
    pergunta: "Qual a maior conquista internacional do Fluminense?",
    respostas: [
      { opcao: "Copa Sul-Americana", correto: false },
      { opcao: "Libertadores da América", correto: true },
      { opcao: "Recopa", correto: false }
    ]
  },
  {
    pergunta: "Qual apelido é usado para o time do Fluminense?",
    respostas: [
      { opcao: "Furacão", correto: false },
      { opcao: "Tricolor das Laranjeiras", correto: true },
      { opcao: "Galo", correto: false }
    ]
  },
  {
    pergunta: "Quem é considerado o maior ídolo da história recente do Fluminense?",
    respostas: [
      { opcao: "Fred", correto: false },
      { opcao: "Renato Gaúcho", correto: false },
      { opcao: "Cano", correto: true }
    ]
  },
  {
    pergunta: "Qual dessas cores faz parte do uniforme do Fluminense?",
    respostas: [
      { opcao: "Verde", correto: true },
      { opcao: "Azul", correto: false },
      { opcao: "Amarelo", correto: false }
    ]
  },
  {
    pergunta: "Qual desses títulos o Fluminense ganhou em 2010?",
    respostas: [
      { opcao: "Brasileirão", correto: true },
      { opcao: "Libertadores", correto: false },
      { opcao: "Copa do Brasil", correto: false }
    ]
  },
  {
    pergunta: "Qual dessas é uma torcida organizada do Fluminense?",
    respostas: [
      { opcao: "Força Jovem", correto: false },
      { opcao: "Young Flu", correto: true },
      { opcao: "Mancha Verde", correto: false }
    ]
  },
  {
    pergunta: "Qual jogador marcou gol na final da Libertadores de 2023 pelo Fluminense?",
    respostas: [
      { opcao: "Ganso", correto: false },
      { opcao: "John Kennedy", correto: true },
      { opcao: "Felipe Melo", correto: false }
    ]
  },
  {
    pergunta: "Quem era o técnico do Fluminense na conquista da Libertadores de 2023?",
    respostas: [
      { opcao: "Abel Braga", correto: false },
      { opcao: "Fernando Diniz", correto: true },
      { opcao: "Muricy Ramalho", correto: false }
    ]
  }
];


// Pegando elementos HTML
const perguntaElemento = document.querySelector(".pergunta");
const respostasElemento = document.querySelector(".respostas");
const progressoElemento = document.querySelector(".progresso");
const textoFinal = document.querySelector(".fim span");
const conteudo = document.querySelector(".conteudo");
const conteudoFinal = document.querySelector(".fim");
const errosLista = document.querySelector(".erros-lista");

// Variáveis de controle
let indiceAtual = 0;
let acertos = 0;
let erros = [];

// Função para carregar pergunta
function carregarPergunta() {
  progressoElemento.innerHTML = `${indiceAtual + 1}/${perguntas.length}`;
  const perguntaAtual = perguntas[indiceAtual];
  perguntaElemento.innerHTML = perguntaAtual.pergunta;
  respostasElemento.innerHTML = "";

  perguntaAtual.respostas.forEach((resposta) => {
    const botao = document.createElement("button");
    botao.classList.add("botao-resposta");
    botao.innerText = resposta.opcao;

    botao.onclick = function () {
      if (resposta.correto) {
        acertos++;
      } else {
        const correta = perguntaAtual.respostas.find(r => r.correto).opcao;
        erros.push({
          pergunta: perguntaAtual.pergunta,
          suaResposta: resposta.opcao,
          correta: correta
        });
      }

      indiceAtual++;

      if (indiceAtual < perguntas.length) {
        carregarPergunta();
      } else {
        finalizarJogo();
      }
    };

    respostasElemento.appendChild(botao);
  });
}

// Função de fim de jogo
function finalizarJogo() {
  textoFinal.innerHTML = `Você acertou ${acertos} de ${perguntas.length}.`;

  // Mostrar os erros
  errosLista.innerHTML = "";
  if (erros.length > 0) {
    erros.forEach(erro => {
      const item = document.createElement("p");
      item.innerHTML = `❌ <strong>${erro.pergunta}</strong><br>
      Sua resposta: <em>${erro.suaResposta}</em><br>
      Correta: <em>${erro.correta}</em><br><br>`;
      errosLista.appendChild(item);
    });
  } else {
    errosLista.innerHTML = "<p>Parabéns! Você acertou tudo! 🎉</p>";
  }

  conteudo.style.display = "none";
  conteudoFinal.style.display = "flex";
}

// Começa o jogo
carregarPergunta();