function jogar() {
  let timesDisponiveis = [
    "flamengo", "americano", "vasco", "botafogo", "palmeiras",
    "atletico-mg", "corinthians", "internacional", "cruzeiro", "atletico-go"
  ];

  let timesEscolhidos = [];
  let timesAdversarios = [];
  let forcaJogador = 0;
  let forcaAdversario = 0;

  let numTimes = parseInt(prompt("Quantos times deseja escolher? (1-10)"));

  // Valida se a entrada é válida
  if (isNaN(numTimes) || numTimes < 1 || numTimes > 10) {
    alert("Número inválido! Escolha um número entre 1 e 10.");
    return;
  }

  // Escolha dos times pelo jogador
  for (let i = 0; i < numTimes; i++) {
    let nomeTime;
    do {
      nomeTime = prompt(`Digite o nome do time ${i + 1}`).toLowerCase().trim();
      
      if (nomeTime === "") {
        alert("O nome do time não pode estar vazio!");
      } else if (timesEscolhidos.includes(nomeTime)) {
        alert("Esse time já foi escolhido! Escolha outro.");
      } else if (timesDisponiveis.includes(nomeTime)) {
        alert("Esse time já existe no campeonato! Escolha um diferente.");
      }
    } while (nomeTime === "" || timesEscolhidos.includes(nomeTime) || timesDisponiveis.includes(nomeTime));

    timesEscolhidos.push(nomeTime);
    forcaJogador += Math.floor(Math.random() * 10) + 1;
  }

  // Escolha dos adversários (somente os da lista)
  for (let i = 0; i < numTimes; i++) {
    let indiceAleatorio = Math.floor(Math.random() * timesDisponiveis.length);
    let timeAdversario = timesDisponiveis[indiceAleatorio];

    // Remove da lista para não repetir
    timesDisponiveis.splice(indiceAleatorio, 1);

    timesAdversarios.push(timeAdversario);
    forcaAdversario += Math.floor(Math.random() * 10) + 1;
  }

  // Exibe os times escolhidos e os adversários
  document.getElementById("informacoesJogador").innerText = `Seus times: ${timesEscolhidos.join(", ")} | Força: ${forcaJogador}`;
  document.getElementById("informacoesComputador").innerText = `Adversários: ${timesAdversarios.join(", ")} | Força: ${forcaAdversario}`;

  // Exibir o botão de resultado
  document.getElementById("resultadoBtn").style.display = "block";
}

function mostrarResultado() {
  let forcaJogador = parseInt(document.getElementById("informacoesJogador").innerText.match(/\d+/)[0]);
  let forcaAdversario = parseInt(document.getElementById("informacoesComputador").innerText.match(/\d+/)[0]);

  let resultadoFinal = document.getElementById("resultadoFinal");

  if (forcaJogador > forcaAdversario) {
    resultadoFinal.innerText = "Seu time venceu o campeonato! 🏆";
  } else if (forcaJogador < forcaAdversario) {
    resultadoFinal.innerText = "Os adversários venceram o campeonato! 😢";
  } else {
    resultadoFinal.innerText = "Empate! O campeonato foi equilibrado! ⚽";
  }
}
